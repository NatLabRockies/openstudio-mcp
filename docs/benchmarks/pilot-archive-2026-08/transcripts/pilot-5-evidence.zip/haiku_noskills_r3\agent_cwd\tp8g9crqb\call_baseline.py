# This demonstrates the tool call structure for create_baseline_osm
name = "llm-test-baseline"
ashrae_sys_num = None
floor_to_floor_height = 4
num_floors = 2
perimeter_zone_depth = 3
wwr = None

print(f"Creating baseline building: {name}")
print(f"  - Floors: {num_floors}")
print(f"  - Floor-to-floor height: {floor_to_floor_height} m")
print(f"  - Perimeter zone depth: {perimeter_zone_depth} m")
print(f"  - HVAC system: {ashrae_sys_num or 'None (no HVAC)'}")
print(f"  - Window-to-wall ratio: {wwr or 'None (no windows)'}")
