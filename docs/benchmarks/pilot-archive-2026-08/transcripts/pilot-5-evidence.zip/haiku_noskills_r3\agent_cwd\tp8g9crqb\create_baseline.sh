#!/bin/bash
# Call the create_baseline_osm MCP tool via the OpenStudio server
# This will create a 2-story commercial building with perimeter and core zones

echo "Creating baseline OSM model: llm-test-baseline"
echo "Configuration:"
echo "  - Name: llm-test-baseline"
echo "  - Stories: 2"
echo "  - Floor-to-floor height: 4.0 m"
echo "  - Perimeter zone depth: 3.0 m"
echo "  - HVAC system: None (no HVAC)"
echo "  - Window-to-wall ratio: None (no windows)"
echo ""
echo "Baseline model will be auto-loaded into memory..."
